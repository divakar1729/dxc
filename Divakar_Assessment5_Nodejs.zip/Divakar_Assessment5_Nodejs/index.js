var express = require("express");

var app = express();
app.set('view engine', 'ejs');

//app.use('./assets',express.static("assets"))
var fs=require('fs')
var filedata=fs.readFileSync("./resources/about.txt","utf8")

app.get("/",function(request,response){
    response.send("<h1>Hii Welcome</h1>")
})
app.get("/about",function(request,response){
  
    response.render('about',{data:filedata})
})

console.log("Server started on port: 5000")

app.listen(5000);