package com.assessment.quiz.model;

public class Quiz {
	private int questionNumber;
	private String question;
	private String answer;
	private int marks;
	private int appeared;
	
	
	public Quiz() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Quiz(int questionNumber, String question, String answer, int marks, int appeared) {
		super();
		this.questionNumber = questionNumber;
		this.question = question;
		this.answer = answer;
		this.marks = marks;
		this.appeared = appeared;
	}


	public int getAppeared() {
		return appeared;
	}


	public void setAppeared(int appeared) {
		this.appeared = appeared;
	}


	public int getQuestionNumber() {
		return questionNumber;
	}


	public void setQuestionNumber(int questionNumber) {
		this.questionNumber = questionNumber;
	}


	public String getQuestion() {
		return question;
	}


	public void setQuestion(String question) {
		this.question = question;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}


	public int getMarks() {
		return marks;
	}


	public void setMarks(int marks) {
		this.marks = marks;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((answer == null) ? 0 : answer.hashCode());
		result = prime * result + appeared;
		result = prime * result + marks;
		result = prime * result + ((question == null) ? 0 : question.hashCode());
		result = prime * result + questionNumber;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Quiz other = (Quiz) obj;
		if (answer == null) {
			if (other.answer != null)
				return false;
		} else if (!answer.equals(other.answer))
			return false;
		if (appeared != other.appeared)
			return false;
		if (marks != other.marks)
			return false;
		if (question == null) {
			if (other.question != null)
				return false;
		} else if (!question.equals(other.question))
			return false;
		if (questionNumber != other.questionNumber)
			return false;
		return true;
	}


	
	
	
}
