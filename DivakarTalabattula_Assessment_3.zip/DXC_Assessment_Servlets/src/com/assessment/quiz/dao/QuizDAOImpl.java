package com.assessment.quiz.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.assessment.quiz.jdbc.DBConnection;
import com.assessment.quiz.model.Quiz;

public class QuizDAOImpl implements QuizDAO {

	Connection connection = DBConnection.getConnection();

	@Override
	public List<Quiz> displayQuestion() {

		List<Quiz> allQuestions = new ArrayList<Quiz>();

		try {
			Statement stat = connection.createStatement();
			ResultSet res = stat.executeQuery("SELECT * FROM quiz");

			while (res.next()) {
				Quiz quiz = new Quiz();
				quiz.setQuestionNumber(res.getInt(1));
				quiz.setQuestion(res.getString(2));
				quiz.setAnswer(res.getString(3));
				quiz.setMarks(res.getInt(4));

				allQuestions.add(quiz);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// TODO Auto-generated method stub
		return allQuestions;

	}

	@Override
	public int calculateResult() {
		// TODO Auto-generated method stub

		return 0;
	}

}
