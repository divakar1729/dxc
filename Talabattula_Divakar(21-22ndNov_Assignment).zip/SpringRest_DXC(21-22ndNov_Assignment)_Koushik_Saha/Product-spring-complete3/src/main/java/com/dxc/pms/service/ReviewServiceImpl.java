package com.dxc.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.pms.dao.ReviewDAO;
import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	ReviewDAO reviewDAO; 
	
	Product product;
	@Override
	public List<Review> getAllReview(int productId) {
		System.out.println(productId);
		return reviewDAO.getAllReview(productId);
		
	}
	@Override
	public boolean addReview(int productId,Review review) {
		return reviewDAO.addReview(productId,review);
	}
	
	@Override
	public Review getReview(int productId, int reviewId) {
		
		return reviewDAO.getReview(productId,reviewId);
	}
	@Override
	public boolean deleteReview(int productId, int reviewId) {
		
		return reviewDAO.deleteReview(productId,reviewId);
	}
	@Override
	public boolean updateReview(int productId, int reviewId,Review review) {
		
		return reviewDAO.updateReview(productId,reviewId,review);
	}

	
}
