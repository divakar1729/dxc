package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;
import com.dxc.pms.service.ReviewService;

@RestController
@RequestMapping("review")
@CrossOrigin(origins = {"http://localhost:3000","http://localhost:4200"})
public class ReviewController {

	@Autowired
	ReviewService reviewService;
	Product product;
	Review review;
	//To fetch all Reviews of a particular product
		@GetMapping("/{productId}")
		public ResponseEntity<List<Review>> getAllReview(@PathVariable("productId")int productId) {
			System.out.println("Fetching all reviews" );
			System.out.println(productId);
			List<Review> allReview = reviewService.getAllReview(productId);
			System.out.println(allReview);
			return new ResponseEntity<List<Review>>(allReview,HttpStatus.OK);
		}
		
		
		
		@PostMapping("/{productId}")
		public boolean saveReview(@PathVariable("productId")int productId,@RequestBody Review review) {
			System.out.println("saving review");
     		reviewService.addReview(productId,review);
     		return true;
				
		}
	
		@GetMapping("/prodId:{productId}/rId:{reviewId}")
		public Review getReview(@PathVariable("productId")int productId,@PathVariable("reviewId")int reviewId) {
			
			review = reviewService.getReview(productId, reviewId);
			System.out.println(review);
			return review;
		}
		
		
		
		
		
		@DeleteMapping("/delete/prodId:{productId}/rId:{reviewId}")
		public Boolean deleteReview(@PathVariable("productId")int productId,@PathVariable("reviewId")int reviewId) {
			
			System.out.println("delete review called " );
		    
			reviewService.deleteReview(productId,reviewId);
			
			return true;
			}
		
		@PutMapping("/update/prodId:{productId}/rId:{reviewId}")
		public Boolean updateReview(@PathVariable("productId")int productId,@PathVariable("reviewId")int reviewId,@RequestBody Review review) {
			
			reviewService.updateReview(productId, reviewId, review);
			return true;
		}
		
		
		
		
		}

