import React, { PureComponent } from 'react'
import ListProductComponent from './component/ListProductComponent';
import ProductComponent from './component/ProductComponent';
import SearchProduct from './component/SearchProduct';
import ReviewComponent from './component/ReviewComponent';


import './App.css'
import {Switch,Route} from 'react-router-dom';
import {BrowserRouter as Router} from 'react-router-dom';

import ProductComponentByName from './component/ProductComponentByName';
class App extends PureComponent {
  constructor(props) {
    super(props)

    this.state = {
      
    }
  }

  render() {
    return (
      <div>
        <h1><center>My Product App</center></h1>
        <br></br>
        <Router>
          <Switch>
          <Route exact path="/" component={ListProductComponent}></Route>
          {/* <Route exact path="/product" component={ListProductComponent}></Route> */}
          <Route exact path="/product/:prodId" component={ProductComponent}></Route>
          <Route exact path="/product/search/searchProduct/" component={SearchProduct}></Route>
          <Route exact path="/productSearch/:prodName" component={ProductComponentByName}></Route>
          <Route exact path="/product/review/prodId=/:productId/rId=/:reviewId" component={ReviewComponent}></Route>
          {/* <Route exact path="/product/review/prodId=productId/rId=reviewId" component={ReviewComponent}></Route> */}
          

          </Switch>
        </Router>
      </div>
    )
  }
}

export default App