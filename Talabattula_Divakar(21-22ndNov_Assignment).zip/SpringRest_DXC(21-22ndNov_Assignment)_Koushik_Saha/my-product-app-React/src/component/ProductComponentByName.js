import React, { Component } from 'react'
import ProductDataService from "../service/ProductDataService";



class ProductComponentByName extends Component {

    
    constructor(props) {
        super(props);
        this.state = ({
            productName: this.props.match.params.prodName,
            products: []
        })
    }

    componentWillMount() {
        ProductDataService.searchProduct(this.state.productName).then(response =>
            this.setState({
                products: response.data
            })
        )
    }

    render() {
        return (
            <div className="container">
                <table cellSpacing="10" cellPadding="10" border="2">
                    <thead>
                        <tr>
                            <th>Product Id</th>
                            <th>Product Name</th>
                            <th>Quantity On Hand</th>
                            <th>Price</th>
                            <th>Reviews</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.products.map(product =>
                            <tr key={product.productId}>
                                <td>{product.productId}</td>
                                <td>{product.productName}</td>
                                <td>{product.quantityOnHand}</td>
                                <td>{product.price}</td>
                                <td>
                                    <table cellPadding="5" cellSpacing="5" >
                                    <thead>
                                        <tr>
                                          <th>ReviewId</th>
                                          <th>Review</th>
                                          <th>Rating</th>
                                          </tr>
                                     </thead>
                                     <tbody>
                                     {product.reviews.map(review => (
                                     <tr key={review.reviewId}>
                                     <td>{review.reviewId}</td>
                                     <td>{review.review}</td>
                                     <td>{review.reviewRating}</td></tr>))}
                                     </tbody>
                                    </table>
                                </td>

                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        );
    }
}

export default ProductComponentByName