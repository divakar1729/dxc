import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import { isString } from 'util';

class ProductComponent extends Component {

    constructor(props) {
        super(props);
        this.state = ({
            productId: this.props.match.params.prodId,
            productName: '',
            quantityOnHand: '',
            price: '',
            readOnly: false,
            buttonMsg: 'Add',
            className: 'btn btn-outline-success mb-2',
            message: ''
        })
        this.onSubmit = this.onSubmit.bind(this)
        this.validateProductForm = this.validateProductForm.bind(this)
    }

    componentWillMount() {
        if (this.state.productId === undefined) {
            this.setState({
                productId: ''
            })
        }
        if (this.state.productId !== undefined) {
            ProductDataService.getProduct(this.state.productId).then(
                response => {
                    this.setState({
                        productName: response.data.productName,
                        quantityOnHand: response.data.quantityOnHand,
                        price: response.data.price
                    })
                    this.onChangeReadOnly(this.state.productId)
                }
            )
        }
    }

    onChangeReadOnly(productId) {
        if (productId !== 0) {
            this.setState({
                readOnly: true,
                buttonMsg: 'Update',
                className: 'btn btn-outline-warning mb-2'
            })
        }
    }


    onSubmit(product) {
        if (!this.state.readOnly) {
            ProductDataService.addProduct(product).then(() =>
                this.props.history.push('/')
            ).catch(err => {
                this.setState ({
                    message: 'Product Id ' + product.productId + ' already exists.'
                })
            })

        } else {
            ProductDataService.updateProduct(product).then(() => this.props.history.push('/'))
        }
    }

    validateProductForm(product) {
        let error = {}
        if (!product.productId) {
            error.productId = "Enter a Product Id"
        }
        else if (!product.productName) {
            error.productName = "Enter a Product Name";
        }
        else if (!product.quantityOnHand) {
            error.quantityOnHand = "Enter Quantity On Hand"
        }
        else if (!product.price) {
            error.price = "Enter Price"
        }
        else if (isNaN(product.quantityOnHand)) {
            error.quantityOnHand = "Enter a valid quantity"
        }
        else if (isNaN(product.price)) {
            error.price = "Enter a valid price"
        }
        else if (!isString(product.productName)) {
            error.productName = "Enter a valid Product Name"
        }
        else if (product.productName.length < 3) {
            error.productName = "Enter atleast 3 characters in Product Name"
        }
        else if (product.price < 0) {
            error.price = "Price cannot be negative"
        }
        else if (product.quantityOnHand < 0) {
            error.price = "Quantity cannot be negative"
        }
        else if (product.productId < 0) {
            error.productId = "Product Id cannot be negative"
        }
        else if (isNaN(product.productId)) {
            error.productId = "Enter a valid Product Id"
        }
        return error;

    }

    render() {
        let { productId, productName, quantityOnHand, price } = this.state
        return (
            <div className='container'>
                <h1>Add/Update</h1>
                <br></br>
                {this.state.message && <div className='alert alert-danger'>{this.state.message}</div>}
                <Formik initialValues={{ productId, productName, quantityOnHand, price }} enableReinitialize={true} onSubmit={this.onSubmit} validateOnChange={false} validateOnBlur={false} validate={this.validateProductForm}>
                    <Form>
                        <ErrorMessage name='productId' component='div' className='alert alert-danger'></ErrorMessage>
                        <ErrorMessage name='productName' component='div' className='alert alert-danger'></ErrorMessage>
                        <ErrorMessage name='quantityOnHand' component='div' className='alert alert-danger'></ErrorMessage>
                        <ErrorMessage name='price' component='div' className='alert alert-danger'></ErrorMessage>

                        <fieldset className='form-group'>
                            <label>Product Id</label>
                            <Field className='form-control' type='text' name='productId' readOnly={this.state.readOnly}>
                            </Field>
                        </fieldset>
                        <fieldset className='form-group'>
                            <label>Product Name</label>
                            <Field className='form-control' type='text' name='productName'>
                            </Field>
                        </fieldset>
                        <fieldset className='form-group'>
                            <label>Quantity On Hand</label>
                            <Field className='form-control' type='text' name='quantityOnHand'>
                            </Field>
                        </fieldset>
                        <fieldset className='form-group'>
                            <label>Price</label>
                            <Field className='form-control' type='text' name='price'>
                            </Field>
                        </fieldset>
                        <br></br>
                        <button type="submit" className={this.state.className}>{this.state.buttonMsg}</button>
                    </Form>
                </Formik>
            </div>
        );
    }
}

export default ProductComponent;