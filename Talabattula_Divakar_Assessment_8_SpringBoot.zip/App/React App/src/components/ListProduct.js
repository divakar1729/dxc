import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';

class ListProduct extends Component {

    constructor(props) {
        super(props);
        this.state = ({
            products: [],
            message: ''
        })
        this.refreshProduct = this.refreshProduct.bind(this)
        this.deleteButtonClicked = this.deleteButtonClicked.bind(this)
        this.updateButtonClicked = this.updateButtonClicked.bind(this)
        this.addButtonClicked = this.addButtonClicked.bind(this)
        this.searchButtonClicked = this.searchButtonClicked.bind(this)
    }

    componentWillMount() {
        this.refreshProduct()
    }

    refreshProduct() {
        ProductDataService.getAllProducts().then(
            response => {
                this.setState({
                    products: response.data
                })
            }
        )
    }

    deleteButtonClicked(productId) {
        ProductDataService.deleteProduct(productId).then(
            response => {
                this.setState({
                    message: 'Product Id ' + productId + ' deleted successfully.'
                })
                this.refreshProduct()

            }
        )
    }

    addButtonClicked() {
        this.props.history.push(`/productAdd/`)
    }

    updateButtonClicked(productId) {
        this.props.history.push(`/productUpdate/${productId}`)
    }

    searchButtonClicked() {
        this.props.history.push(`/productSearchByName/`)
    }

    render() {
        return (
            <div>
                <div className='container'>
                    {this.state.message && <div className='alert alert-success'>{this.state.message}</div>}
                    <table className="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>Quantity On Hand</th>
                                <th>Price</th>
                                <th>Delete/Update</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.products.map(product =>
                                <tr key={product.productId}>
                                    <td>{product.productId}</td>
                                    <td>{product.productName}</td>
                                    <td>{product.quantityOnHand}</td>
                                    <td>{product.price}</td>
                                    <td>
                                        <button type="button" className="btn btn-outline-danger" onClick={() => this.deleteButtonClicked(product.productId)}>Delete</button>
                                        <span>&nbsp;</span>
                                        <button type="button" className="btn btn-outline-warning" onClick={() => this.updateButtonClicked(product.productId)}>Update</button>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                    <button type="button" className='btn btn-outline-success' onClick={() => this.addButtonClicked()}>Add Product</button>&nbsp;
                    <button type="button" className='btn btn-outline-primary' onClick={() => this.searchButtonClicked()}>Search Product By Name</button>
                </div>

            </div>
        );
    }
}

export default ListProduct;