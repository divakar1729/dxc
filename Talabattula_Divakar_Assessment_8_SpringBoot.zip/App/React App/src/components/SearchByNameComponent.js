import React, { Component } from 'react';
import { Formik, Field, Form, ErrorMessage } from 'formik';


class SearchByNameComponent extends Component {

    constructor(props) {
        super(props);
        this.state = ({
            productName: '',

        })
        this.validateProductForm = this.validateProductForm.bind(this)
        this.onSubmit = this.onSubmit.bind(this)
    }


    validateProductForm(product) {
        let error = {}
        if (!product.productName) {
            error.productName = "Enter a Product Name";
        }
        else if (product.productName.length < 3) {
            error.productName = "Enter atleast 3 characters in Product Name"
        }
        return error;

    }

    onSubmit(product) {
        this.props.history.push(`/productSearch/${product.productName}`)
    }

    render() {
        let { productName } = this.state
        return (
            <div className='container'>
                <h1>Search Product By Name</h1>
                <br></br>
                <Formik initialValues={{ productName }} enableReinitialize={true} onSubmit={this.onSubmit} validateOnChange={false} validateOnBlur={false} validate={this.validateProductForm}>
                    <Form>
                        <ErrorMessage name='productName' component='div' className='alert alert-danger'></ErrorMessage>


                        <fieldset className='form-group'>
                            <label>Product Name</label>
                            <Field className='form-control' type='text' name='productName'>
                            </Field>
                        </fieldset>


                        <br></br>
                        <button type="submit" className='btn btn-primary'>Search</button>
                    </Form>
                </Formik>

            </div >
        );
    }
}

export default SearchByNameComponent;