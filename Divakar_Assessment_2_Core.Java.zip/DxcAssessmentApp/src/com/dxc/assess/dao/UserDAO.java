package com.dxc.assess.dao;

import java.util.List;

import com.dxc.assess.model.User;

public interface UserDAO {
	
	public boolean userValidate(User user);
	
	public void getAllTrainingDetails();
	
	public void updatePercentage();
	
}