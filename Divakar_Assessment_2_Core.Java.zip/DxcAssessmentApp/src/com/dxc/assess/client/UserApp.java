package com.dxc.assess.client;

import java.util.Scanner;

import com.dxc.assess.dao.UserDAO;
import com.dxc.assess.dao.UserDAOImpl;
import com.dxc.assess.model.User;

public class UserApp {

	public void validate() {

		UserDAO userDAO = new UserDAOImpl();

		Scanner s = new Scanner(System.in);
		System.out.println("Enter your Username: ");
		String username = s.next();
		System.out.println("Enter your Password: ");
		String password = s.next();

		User user = new User(username, password);

		if (!userDAO.userValidate(user)) {
			System.exit(0);
		}

		while (true) {
			System.out.println("MENU");
			System.out.println("1. Display All Training Records");
			System.out.println("2. Display Records one by one and update the percentage");

			System.out.println("3. Exit");
			int choice = 0;
			System.out.println("Please enter your choice: (1-3)");

			choice = s.nextInt();

			switch (choice) {

			case 1:
				userDAO.getAllTrainingDetails();
				break;
				
			case 2:
				userDAO.updatePercentage();
				break;

			case 3:
				System.out.println("Thanks For using my App");
				System.exit(0);
			}
		}

	}
}


