package com.testCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Test5 {
	
	public WebDriver driver;
	public String Browser = "chrome";

	@Test
	public void testcase1() {
		SoftAssert st = new SoftAssert();

		if (Browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver = new ChromeDriver(); // OpenBrowser
		} else if (Browser.equalsIgnoreCase("mozilla")) {
			System.setProperty("webdriver.firefox.marionette", "geckodriver.exe");
			driver = new FirefoxDriver();
		} else if (Browser.equalsIgnoreCase("ie")) {
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}

		driver.get("http://localhost:8080/login.do"); // open url
		driver.manage().window().maximize(); // maximize browser

		// Login
		WebElement username = driver.findElement(By.xpath("//input[@name='username']"));
		username.sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();

		// click on task
		driver.findElement(By.xpath("//a[@class='content tasks']//img[@class='sizer']")).click();

		// click on pro and customer
		driver.findElement(By.xpath("//a[contains(text(),'Projects & Customers')]")).click();

		// click on create project
		driver.findElement(By.xpath("//body/div[@id='container']/form[@id='customersProjectsForm']/table[@class='mainContentPadding rightPadding']/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/input[2]")).click();
		
		// select CustomerA
		WebElement sel = driver.findElement(By.xpath("//select[@name='customerId']"));
		Select s = new Select(sel);
		
		s.selectByVisibleText("CustomerA");
		
		//Fill the details
		driver.findElement(By.xpath("//input[@name='name']")).sendKeys("ProjectB");
		
		driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("DescriptionB");

		// Clicking radio button and submit button
		driver.findElement(By.xpath("//input[@id='add_tasks_action']")).click();
		driver.findElement(By.xpath("//input[@name='createProjectSubmit']")).click();

		// verifysucessmsg
		try {
			driver.findElement(By.xpath("//span[@class='successmsg']")).isDisplayed();
			// Logout
			driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
		} catch (Throwable t) {
			st.fail("Sucess msg does not displayed...");
			// Logout
			driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
			// cancel creation
			driver.findElement(By.xpath("//input[@id='DiscardChangesButton']")).click();
		}

		// close browser
		driver.quit();
		st.assertAll();

	}


}
