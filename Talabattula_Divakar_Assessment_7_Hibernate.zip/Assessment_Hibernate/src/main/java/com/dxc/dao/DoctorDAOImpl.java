package com.dxc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.model.Doctor;
import com.dxc.util.HibernateUtil;

public class DoctorDAOImpl implements DoctorDAO {

	SessionFactory sf = HibernateUtil.getSessionFactory();

	public Doctor getDoctor(int doctorId) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Doctor doctor = (Doctor) session.get(Doctor.class, doctorId);
		return doctor;
	}

	public List<Doctor> getAllDoctors() {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		List<Doctor> list = session.createQuery("FROM Doctor").list();
		return list;
	}

	public void addDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		session.close();
		System.out.println(doctor.getDoctorName() + " saved successfully");

	}

	public void deleteDoctor(int doctorId) {
		// TODO Auto-generated method stub
		Doctor doctor = getDoctor(doctorId);
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.delete(doctor);
		transaction.commit();
		session.close();
		System.out.println(doctor.getDoctorName() + " deleted successfully");
	}

	public void updateDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(doctor);
		transaction.commit();
		session.close();
	}

	public List<Doctor> getDoctorByName(String doctorName) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		String hql = "FROM Doctor AS D WHERE D.doctorName = :doctorName";
		Query query = session.createQuery(hql);
		query.setString("doctorName", doctorName);
		List<Doctor> list = query.list();
		return list;	}

	public boolean isDoctorExists(int doctorId) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Doctor doctor = (Doctor) session.get(Doctor.class, doctorId);

		if (doctor == null) {
			return false;
		}
		return true;
	}

}
