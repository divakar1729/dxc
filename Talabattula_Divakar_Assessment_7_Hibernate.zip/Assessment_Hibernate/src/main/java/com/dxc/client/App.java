package com.dxc.client;

import com.dxc.dao.DoctorDAO;
import com.dxc.dao.DoctorDAOImpl;

public class App 
{
    public static void main( String[] args )
    {
    	
    }
}
