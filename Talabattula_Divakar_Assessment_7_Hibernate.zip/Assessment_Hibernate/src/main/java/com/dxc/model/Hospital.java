package com.dxc.model;

import javax.persistence.Embeddable;

@Embeddable
public class Hospital {
	
	private String hospitalName;
	private String hospitalCity;
	
	public Hospital() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hospital(String hospitalName, String hospitalCity) {
		super();
		this.hospitalName = hospitalName;
		this.hospitalCity = hospitalCity;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getHospitalCity() {
		return hospitalCity;
	}

	public void setHospitalCity(String hospitalCity) {
		this.hospitalCity = hospitalCity;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hospitalCity == null) ? 0 : hospitalCity.hashCode());
		result = prime * result + ((hospitalName == null) ? 0 : hospitalName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hospital other = (Hospital) obj;
		if (hospitalCity == null) {
			if (other.hospitalCity != null)
				return false;
		} else if (!hospitalCity.equals(other.hospitalCity))
			return false;
		if (hospitalName == null) {
			if (other.hospitalName != null)
				return false;
		} else if (!hospitalName.equals(other.hospitalName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Hospital [hospitalName=" + hospitalName + ", hospitalCity=" + hospitalCity + "]";
	}

}
