package com.dxc.dao;

import java.util.List;

import com.dxc.model.Doctor;
import com.dxc.model.Hospital;

import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {

	DoctorDAOImpl impl;

	protected void setUp() throws Exception {
		impl = new DoctorDAOImpl();
	}

	public void testGetDoctor() {
		Hospital hospital = new Hospital("ABC", "Delhi");
		Doctor doctor = new Doctor(5, "Something", 12, hospital);
		impl.addDoctor(doctor);
		Doctor doctor2 = impl.getDoctor(doctor.getDoctorId());

		assertEquals(doctor, doctor2);
		impl.deleteDoctor(doctor.getDoctorId());
	}

	public void testGetAllDoctors() {
		Hospital hospital = new Hospital("ABC", "Delhi");
		Doctor doctor = new Doctor(1, "Something", 12, hospital);
		impl.addDoctor(doctor);
		List<Doctor> allDoctors = impl.getAllDoctors();

		assertNotSame(allDoctors.size() + 1, allDoctors.size());
		impl.deleteDoctor(doctor.getDoctorId());
	}

	public void testAddDoctor() {
		Hospital hospital = new Hospital("ABC", "Delhi");
		Doctor doctor = new Doctor(2, "Something", 12, hospital);
		List<Doctor> allDoctors1 = impl.getAllDoctors();
		impl.addDoctor(doctor);
		List<Doctor> allDoctors2 = impl.getAllDoctors();
		assertNotSame(allDoctors1.size(), allDoctors2.size());
		impl.deleteDoctor(doctor.getDoctorId());
	}

	public void testDeleteDoctor() {
		Hospital hospital = new Hospital("ABC", "Delhi");
		Doctor doctor = new Doctor(3, "Something", 12, hospital);
		impl.addDoctor(doctor);
		List<Doctor> allDoctors1 = impl.getAllDoctors();
		impl.deleteDoctor(doctor.getDoctorId());
		List<Doctor> allDoctors2 = impl.getAllDoctors();

		assertNotSame(allDoctors1.size(), allDoctors2.size());
	}

	public void testUpdateDoctor() {
		Hospital hospital = new Hospital("ABC", "Delhi");
		Doctor doctor = new Doctor(4, "Something", 12, hospital);
		Doctor doctor2 = new Doctor(4, "Some", 10, hospital);

		impl.addDoctor(doctor);
		impl.updateDoctor(doctor2);

		assertNotSame(impl.getDoctor(doctor.getDoctorId()), doctor2);
		impl.deleteDoctor(doctor.getDoctorId());
	}

	public void testGetDoctorByName() {
		Hospital hospital = new Hospital("ABC", "Delhi");
		Doctor doctor = new Doctor(22, "Mustaf", 12, hospital);
		Doctor doctor2 = new Doctor(23, "Mustaf", 12, hospital);
		impl.addDoctor(doctor);
		impl.addDoctor(doctor2);
		List<Doctor> allDoctors = impl.getDoctorByName("Mustaf");

		assertEquals(2, allDoctors.size());
		impl.deleteDoctor(doctor.getDoctorId());
		impl.deleteDoctor(doctor2.getDoctorId());
	}

	public void testIsDoctorExists() {
		Hospital hospital = new Hospital("ABC", "Delhi");
		Doctor doctor = new Doctor(7, "Something", 12, hospital);
		impl.addDoctor(doctor);
		assertEquals(true, impl.isDoctorExists(doctor.getDoctorId()));
		impl.deleteDoctor(doctor.getDoctorId());
	}

}
